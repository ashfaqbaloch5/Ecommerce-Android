package co.sandyedemo.ecomdemo.Fragments;

import android.app.Activity;

public class OrderConfirmation extends Activity {
}
